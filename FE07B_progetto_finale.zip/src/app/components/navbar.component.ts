import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { AuthGuardGuard } from '../_guard/auth-guard.guard';

@Component({
  selector: 'app-navbar',
  template: `
    <nav class="navbar navbar-expand navbar-dark bg-dark bg-gradient">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <i class="bi bi-circle-fill m-1 pallina"></i>
          <i class="bi bi-circle-fill m-1 pallino"></i>
          <i class="bi bi-circle-fill m-1 pallini"></i>
          <div class="nav navbar-nav flex-grow-1 justify-content-around">
            <a
              class="nav-link"
              aria-current="page"
              [routerLink]="['']"
              routerLinkActive="router-link-active"
              ><i class="bi bi-house-door-fill m-1"></i>Home</a
            >
            <a
              class="nav-link"
              [routerLink]="['login']"
              routerLinkActive="router-link-active"
              ><i class="bi bi-person-circle m-1"></i>Login</a
            >
            <a
              class="nav-link"
              [routerLink]="['signup']"
              routerLinkActive="router-link-active"
              ><i class="bi bi-person-plus-fill m-1"></i>Sign Up</a
            >
            <a
              class="nav-link"
              [routerLink]="['users']"
              routerLinkActive="router-link-active"
              ><i class="bi bi-people-fill m-1"></i>Users</a
            >
            <a
              class="nav-link"
              [routerLink]="['clienti']"
              routerLinkActive="router-link-active"
              ><i class="bi bi-person-check-fill m-1"></i>Clienti</a
            >
            <a
              class="nav-link"
              [routerLink]="['fatture']"
              routerLinkActive="router-link-active"
              ><i class="bi bi-file-earmark-text-fill m-1"></i>Fatture</a
            >
            <a
              class="nav-link btn btn-danger text-white"
              (click)="onlogOut()"
              [hidden]="!this.authSrv.loggedIn()"
              >Logout</a
            >
          </div>
        </div>
      </div>
    </nav>
  `,
  styles: [
    `
      .pallina {
        color: red;
      }

      .pallino {
        color: yellow;
      }

      .pallini {
        color: #14d928;
      }
    `,
  ],
})
export class NavbarComponent implements OnInit {
  constructor(private auth: AuthGuardGuard, public authSrv: AuthService) {}
  ngOnInit(): void {}

  onlogOut() {
    if (this.authSrv.loggedIn()) {
      this.authSrv.logOut();
    } else {
      alert('Non hai ancora effettuato il login!');
    }
  }
}
