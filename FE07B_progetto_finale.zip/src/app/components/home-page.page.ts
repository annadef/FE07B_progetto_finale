import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <div class="container d-flex justify-content-center mt-5">
      <div>
        <h3 class="text-white">
          <strong>Benvenuto nel sistema di fatturazione</strong>
        </h3>
      </div>
    </div>
    <div class="container d-flex justify-content-center">
      <button
        class="custom-btn btn-5 m-4"
        [routerLink]="['/login']"
        routerLinkActive="active"
      >
        <span>Accedi</span>
      </button>
      <button
        class="custom-btn btn-5 m-4"
        [routerLink]="['/signup']"
        routerLinkActive="active"
      >
        Registrati
      </button>
    </div>

    <h6 class="text-center text-white mt-4">
      <strong>Seguici sui nostri social:</strong>
    </h6>
    <div class="wrapper d-flex justify-content-center">
      <div class="icon facebook">
        <div class="tooltip">Facebook</div>
        <span><i class="bi bi-facebook"></i></span>
      </div>
      <div class="icon twitter">
        <div class="tooltip">Twitter</div>
        <span><i class="bi bi-twitter"></i></span>
      </div>
      <div class="icon instagram">
        <div class="tooltip">Instagram</div>
        <span><i class="bi bi-instagram"></i></span>
      </div>
      <div class="icon github">
        <div class="tooltip">Github</div>
        <span><i class="bi bi-github"></i></span>
      </div>
      <div class="icon youtube">
        <div class="tooltip">Youtube</div>
        <span><i class="bi bi-youtube"></i></span>
      </div>
    </div>
  `,
  styles: [
    `
      .custom-btn {
        width: 130px;
        height: 40px;
        color: #fff;
        border-radius: 5px;
        padding: 10px 25px;
        font-weight: 500;
        background: transparent;
        cursor: pointer;
        transition: all 0.3s ease;
        position: relative;
        display: inline-block;
        box-shadow: inset 2px 2px 2px 0px rgba(255, 255, 255, 0.5),
          7px 7px 20px 0px rgba(0, 0, 0, 0.1),
          4px 4px 5px 0px rgba(0, 0, 0, 0.1);
        outline: none;
      }

      .btn-5 {
        width: 130px;
        height: 40px;
        line-height: 42px;
        padding: 0;
        border: none;
        background: rgb(255, 27, 0);
        background: linear-gradient(
          0deg,
          rgba(255, 27, 0, 1) 0%,
          rgba(251, 75, 2, 1) 100%
        );
      }
      .btn-5:hover {
        color: #f0094a;
        background: transparent;
        box-shadow: none;
      }
      .btn-5:before,
      .btn-5:after {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        height: 2px;
        width: 0;
        background: #f0094a;
        box-shadow: -1px -1px 5px 0px #fff, 7px 7px 20px 0px #0003,
          4px 4px 5px 0px #0002;
        transition: 400ms ease all;
      }
      .btn-5:after {
        right: inherit;
        top: inherit;
        left: 0;
        bottom: 0;
      }
      .btn-5:hover:before,
      .btn-5:hover:after {
        width: 100%;
        transition: 800ms ease all;
      }

      .wrapper .icon {
        position: relative;
        background-color: #ffffff;
        border-radius: 50%;
        padding: 15px;
        margin: 10px;
        width: 50px;
        height: 50px;
        font-size: 18px;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        box-shadow: 0 10px 10px rgba(0, 0, 0, 0.1);
        cursor: pointer;
        transition: all 0.2s cubic-bezier(0.68, -0.55, 0.265, 1.55);
      }

      .wrapper .tooltip {
        position: absolute;
        top: 0;
        font-size: 14px;
        background-color: #ffffff;
        color: #ffffff;
        padding: 5px 8px;
        border-radius: 5px;
        box-shadow: 0 10px 10px rgba(0, 0, 0, 0.1);
        opacity: 0;
        pointer-events: none;
        transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
      }

      .wrapper .tooltip::before {
        position: absolute;
        content: '';
        height: 8px;
        width: 8px;
        background-color: #ffffff;
        bottom: -3px;
        left: 50%;
        transform: translate(-50%) rotate(45deg);
        transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
      }

      .wrapper .icon:hover .tooltip {
        top: -45px;
        opacity: 1;
        visibility: visible;
        pointer-events: auto;
      }

      .wrapper .icon:hover span,
      .wrapper .icon:hover .tooltip {
        text-shadow: 0px -1px 0px rgba(0, 0, 0, 0.1);
      }

      .wrapper .facebook:hover,
      .wrapper .facebook:hover .tooltip,
      .wrapper .facebook:hover .tooltip::before {
        background-color: #3b5999;
        color: #ffffff;
      }

      .wrapper .twitter:hover,
      .wrapper .twitter:hover .tooltip,
      .wrapper .twitter:hover .tooltip::before {
        background-color: #46c1f6;
        color: #ffffff;
      }

      .wrapper .instagram:hover,
      .wrapper .instagram:hover .tooltip,
      .wrapper .instagram:hover .tooltip::before {
        background-color: #e1306c;
        color: #ffffff;
      }

      .wrapper .github:hover,
      .wrapper .github:hover .tooltip,
      .wrapper .github:hover .tooltip::before {
        background-color: #333333;
        color: #ffffff;
      }

      .wrapper .youtube:hover,
      .wrapper .youtube:hover .tooltip,
      .wrapper .youtube:hover .tooltip::before {
        background-color: #de463b;
        color: #ffffff;
      }
    `,
  ],
})
export class HomePagePage implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
