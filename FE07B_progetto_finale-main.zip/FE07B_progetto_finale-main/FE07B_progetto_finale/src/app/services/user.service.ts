import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  myApiUrl: string = environment.pathApi;
  constructor(private http: HttpClient) {}
  getAll(k: number) {
    return this.http.get<any>(
      this.myApiUrl + '/api/users?page=' + k + '&size=20&sort=id,ASC'
    );
  }
}
