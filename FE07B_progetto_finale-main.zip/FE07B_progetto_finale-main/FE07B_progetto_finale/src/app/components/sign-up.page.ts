import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  template: `
    <div class="container wrapper">
      <form #form="ngForm" (ngSubmit)="onsignup(form)">
        <h5 class="m-2 text-center">
          Username<i class="bi bi-emoji-sunglasses ms-2"></i>
        </h5>
        <div class="form-field d-flex align-items-center">
          <input
            ngModel
            name="username"
            type="username"
            id="username"
            placeholder="Inserisci username"
            class="text-center"
          />
        </div>
        <h5 class="m-2 text-center">
          Email<i class="bi bi-at ms-2 email"></i>
        </h5>
        <div class="form-field d-flex align-items-center">
          <input
            ngModel
            name="email"
            type="email"
            id="email"
            placeholder="Inserisci email"
            class="text-center"
          />
        </div>
        <h5 class="m-2 text-center">
          Password<i class="bi bi-eye-slash-fill ms-2"></i>
        </h5>
        <div class="form-field d-flex align-items-center">
          <input
            ngModel
            name="password"
            type="password"
            id="password"
            placeholder="Inserisci password"
            class="text-center"
          />
        </div>
        <div class="container">
          <h5 class="text-center">Seleziona il tuo ruolo:</h5>
          <select
            ngModel
            name="ruolo"
            class="form-select my-3"
            aria-label=".form-select-sm example"
          >
            <option selected></option>
            <option value="ROLE_USER">Utente</option>
            <option value="ROLE_ADMIN">Amministratore</option>
          </select>
        </div>
        <button class="btn mt-3" [disabled]="false" type="submit">
          Registrati
        </button>
      </form>
    </div>
  `,
  styles: [
    `
      .wrapper {
        max-width: 550px;
        min-height: 350px;
        margin: 30px auto;
        padding: 40px 30px 30px 30px;
        background-color: #ecf0f3;
        border-radius: 15px;
      }

      i {
        font-size: 18px;
        color: #03a9f4;
      }

      .email {
        font-size: 22px;
      }

      .wrapper .form-field input {
        width: 100%;
        display: block;
        border: none;
        outline: none;
        background: none;
        font-size: 1.2rem;
        color: #666;
        padding: 10px 15px 10px 10px;
      }

      .wrapper .form-field {
        padding-left: 10px;
        margin-bottom: 20px;
        border-radius: 20px;
        box-shadow: inset 8px 8px 8px #cbced1, inset -8px -8px 8px #fff;
      }

      .wrapper .btn {
        box-shadow: none;
        width: 100%;
        height: 40px;
        background-color: #03a9f4;
        color: #fff;
        border-radius: 25px;
        box-shadow: 3px 3px 3px #b1b1b1, -3px -3px 3px #fff;
        letter-spacing: 1.3px;
      }

      .wrapper .btn:hover {
        background-color: #039be5;
      }

      .wrapper a:hover {
        color: #039be5;
      }
    `,
  ],
})
export class SignUpPage implements OnInit {
  constructor(private authSrv: AuthService, private router: Router) {}

  ngOnInit(): void {}

  onsignup(form: NgForm) {
    this.authSrv.signup(form.value).subscribe((res) => {
      alert('Registrazione avvenuta!');
      this.router.navigate(['/login']);
    });
  }
}
