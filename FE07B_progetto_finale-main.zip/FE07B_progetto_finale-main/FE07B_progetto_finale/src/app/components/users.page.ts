import { Component, OnInit } from '@angular/core';
import { Users } from '../_models/user';
import { UserService } from '../services/user.service';

@Component({
  template: `
    <div
      class="container bg-light p-2 mt-4 mb-4 border border-primary border border-5 rounded"
    >
      <div class="row">
        <div class="col-md-12">
          <table class="table table-hover">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Username</th>
                <th scope="col">Email</th>
                <th scope="col">Ruoli</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let user of users">
                <td>{{ user.id }}</td>
                <td>{{ user.username }}</td>
                <td>{{ user.email }}</td>
                <td>
                  <span *ngFor="let ruolo of user.roles">{{
                    ruolo.roleName
                  }}</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="container d-flex justify-content-center">
      <nav aria-label="justify-content-center">
        <ul class="pagination">
          <li class="page-item">
            <button class="page-link" (click)="caricaprevPag(this.p)">
              Previous
            </button>
          </li>

          <li class="page-item" *ngFor="let pagina of maxPag; let p = index">
            <button class="page-link" (click)="caricaPag(p)">
              {{ p + 1 }}
            </button>
          </li>

          <li class="page-item">
            <button class="page-link" (click)="caricanextPag(this.p)">
              Next
            </button>
          </li>
        </ul>
      </nav>
    </div>
  `,
  styles: [],
})
export class UsersPage implements OnInit {
  users!: Array<Users>;
  p: number = 0;
  maxPag!: number[];

  constructor(private usrSrv: UserService) {}

  ngOnInit(): void {
    this.usrSrv.getAll(this.p).subscribe((res) => {
      this.users = res.content;
    });
    this.caricaPag(this.p);
  }

  caricaPag(k: number) {
    this.usrSrv.getAll(k).subscribe((res) => {
      this.users = res.content;
      this.p = k;
      this.maxPag = Array(res.totalPages);
    });
  }

  caricaprevPag(k: number) {
    if (this.p == 0) {
      this.caricaPag(k);
      return;
    } else {
      --k;
      this.caricaPag(k);
      return;
    }
  }

  caricanextPag(k: number) {
    if (this.p == this.maxPag.length - 1) {
      this.caricaPag(k);
      return;
    } else {
      ++k;
      this.caricaPag(k);
      return;
    }
  }
}
