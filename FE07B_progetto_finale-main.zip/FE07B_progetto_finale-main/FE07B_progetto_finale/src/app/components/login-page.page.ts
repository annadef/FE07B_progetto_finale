import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  template: `
    <div class="container-fluid wrapper" id="image">
      <form #form="ngForm" (ngSubmit)="onlogin(form)" class="p-3">
        <div class="form-field d-flex align-items-center">
          <i class="bi bi-person-fill"></i>
          <input
            ngModel
            name="username"
            type="text"
            id="username"
            placeholder="Email"
          />
        </div>
        <div class="form-field d-flex align-items-center">
          <i class="bi bi-key-fill"></i>
          <input
            ngModel
            name="password"
            type="password"
            id="password"
            placeholder="Password"
          />
        </div>
        <button class="btn mt-3" [disabled]="false" type="submit">Login</button>
        <div class="text-center mt-3">
          <a [routerLink]="['/signup']">Sign up</a>
        </div>
      </form>
    </div>
  `,
  styles: [
    `
      .wrapper {
        max-width: 350px;
        min-height: 300px;
        margin: 80px auto;
        padding: 40px 30px 30px 30px;
        background-color: #ecf0f3;
        border-radius: 15px;
      }

      i {
        font-size: 25px;
      }

      .wrapper .form-field input {
        width: 100%;
        display: block;
        border: none;
        outline: none;
        background: none;
        font-size: 1.2rem;
        color: #666;
        padding: 10px 15px 10px 10px;
      }

      .wrapper .form-field {
        padding-left: 10px;
        margin-bottom: 20px;
        border-radius: 20px;
        box-shadow: inset 8px 8px 8px #cbced1, inset -8px -8px 8px #fff;
      }

      .wrapper .btn {
        box-shadow: none;
        width: 100%;
        height: 40px;
        background-color: #03a9f4;
        color: #fff;
        border-radius: 25px;
        box-shadow: 3px 3px 3px #b1b1b1, -3px -3px 3px #fff;
        letter-spacing: 1.3px;
      }

      .wrapper .btn:hover {
        background-color: #039be5;
      }

      .wrapper a {
        text-decoration: none;
        font-size: 0.8rem;
        color: #03a9f4;
      }

      .wrapper a:hover {
        color: #039be5;
      }
    `,
  ],
})
export class LoginPagePage implements OnInit {
  form!: NgForm;
  constructor(private authSrv: AuthService) {}

  ngOnInit(): void {}

  onlogin(form: any) {
    this.authSrv.login(form.value);
  }
}
