import { Component, OnInit } from '@angular/core';
import { FatturaService } from '../services/fattura.service';
import { Router } from '@angular/router';

@Component({
  template: `
    <div class="container mb-4">
      <div class="row">
        <div class="col-4 mt-4" *ngFor="let fattura of fatture">
          <div class="card" style="width: 18rem;">
            <div class="card-body text-center">
              <h5 class="card-title">{{ fattura.name }}</h5>
              <h6 class="card-subtitle mb-2">
                {{ fattura.cliente.ragioneSociale }}
              </h6>
              <p class="card-text">Importo: {{ fattura.importo }} €</p>
              <p class="card-text">Stato Fattura: {{ fattura.stato.nome }}</p>
              <p class="card-text">ID unico: {{ fattura.id }}</p>
              <p class="card-text">
                Data: {{ fattura.data | date: 'd/M/yy, h:mm a' }}
              </p>
              <a
                [routerLink]="['/dettaglifattura/', fattura.id]"
                routerLinkActive="router-link-active"
                class="btn btn-primary btn-sm"
                >Dettagli Fattura</a
              >
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="d-flex justify-content-center">
      <ul class="pagination">
        <li class="page-item">
          <button
            class="page-link bottonePag bottonePrev"
            (click)="caricaprevPag(this.p)"
          >
            Previous
          </button>
        </li>
        <li class="page-item">
          <button class="page-link bottonePag" (click)="caricanextPag(this.p)">
            Next
          </button>
        </li>
      </ul>
    </div>
  `,
  styles: [``],
})
export class FatturePage implements OnInit {
  constructor(private fatturaSrv: FatturaService, private router: Router) {}
  fatture: any;
  numPag!: any;
  p: number = 0;
  k!: number;

  ngOnInit(): void {
    this.caricaPag(0);
  }

  caricaPag(k: number) {
    this.fatturaSrv.getByPage(k).subscribe((res) => {
      this.fatture = res.content;
      this.p = k;
      this.numPag = Array(res.pageable.totalPages);
    });
  }

  caricaprevPag(k: number) {
    if (this.p == 0) {
      this.caricaPag(k);
      return;
    } else {
      --k;
      this.caricaPag(k);
      return;
    }
  }

  caricanextPag(k: number) {
    if (this.p == 205) {
      this.caricaPag(k);
      return;
    } else {
      ++k;
      this.caricaPag(k);
      return;
    }
  }
}
