export class loginUtente {
  username!: string;
  password!: string;
}
