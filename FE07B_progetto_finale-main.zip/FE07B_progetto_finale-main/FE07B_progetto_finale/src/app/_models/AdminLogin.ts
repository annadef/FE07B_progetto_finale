import { loginUtente } from './loginUtente';

export class AdminLogin implements loginUtente {
  username: string = 'admin';
  password: string = '111111';
}
